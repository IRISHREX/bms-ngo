<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Config\Database;
use PDO;
use PDOException;

class VolunteersController {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function getAll(Request $request, Response $response, $args) {
        try {
            $stmt = $this->db->query("SELECT * FROM volunteers ORDER BY created_at DESC");
            $rows = $stmt->fetchAll();
            $volunteers = array_map([$this, 'mapVolunteer'], $rows);

            $response->getBody()->write(json_encode($volunteers));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(200);
        } catch (PDOException $e) {
            $response->getBody()->write(json_encode(["error" => $e->getMessage()]));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
        }
    }

    public function create(Request $request, Response $response, $args) {
        $body = json_decode($request->getBody(), true);
        
        $name = $body['name'] ?? null;
        $phone = $body['phone'] ?? '';
        $email = $body['email'] ?? '';
        $message = $body['message'] ?? '';
        $type = $body['type'] ?? 'volunteer';

        if (!$name) {
            $response->getBody()->write(json_encode(["error" => "Name is required"]));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }

        try {
            $stmt = $this->db->prepare("INSERT INTO volunteers (name, phone, email, message, type) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $phone, $email, $message, $type]);
            
            $insertId = $this->db->lastInsertId();

            $response->getBody()->write(json_encode(["id" => (string)$insertId, "message" => "Application submitted"]));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(201);
        } catch (PDOException $e) {
            $response->getBody()->write(json_encode(["error" => $e->getMessage()]));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
        }
    }

    public function update(Request $request, Response $response, $args) {
        $id = $args['id'];
        $body = json_decode($request->getBody(), true);
        $status = $body['status'] ?? null;
        
        if (!$status) {
            $response->getBody()->write(json_encode(["error" => "Status is required"]));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(400);
        }

        try {
            $stmt = $this->db->prepare("UPDATE volunteers SET status = ? WHERE id = ?");
            $stmt->execute([$status, $id]);
            
            $response->getBody()->write(json_encode(["message" => "Volunteer updated"]));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(200);
        } catch (PDOException $e) {
            $response->getBody()->write(json_encode(["error" => $e->getMessage()]));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
        }
    }

    public function export(Request $request, Response $response, $args) {
        try {
            $stmt = $this->db->query("SELECT * FROM volunteers ORDER BY created_at DESC");
            $rows = $stmt->fetchAll();
            
            $csv = "Name,Phone,Email,Type,Status,Date\n";
            foreach ($rows as $r) {
                // Escape quotes for CSV
                $name = str_replace('"', '""', $r['name']);
                $phone = str_replace('"', '""', $r['phone']);
                $email = str_replace('"', '""', $r['email']);
                $type = str_replace('"', '""', $r['type']);
                $status = str_replace('"', '""', $r['status']);
                $date = str_replace('"', '""', $r['created_at']);
                
                $csv .= "\"$name\",\"$phone\",\"$email\",\"$type\",\"$status\",\"$date\"\n";
            }

            $response->getBody()->write($csv);
            return $response
                ->withHeader('Content-Type', 'text/csv')
                ->withHeader('Content-Disposition', 'attachment; filename="volunteers.csv"')
                ->withStatus(200);
        } catch (PDOException $e) {
            $response->getBody()->write(json_encode(["error" => $e->getMessage()]));
            return $response->withHeader('Content-Type', 'application/json')->withStatus(500);
        }
    }

    private function mapVolunteer($row) {
        return [
            'id' => (string)$row['id'],
            'name' => $row['name'],
            'phone' => $row['phone'],
            'email' => $row['email'],
            'message' => $row['message'],
            'type' => $row['type'],
            'status' => $row['status'],
            'createdAt' => $row['created_at'],
        ];
    }
}
